from django.db import models

class Students(models.Model):
    Student_id = models.IntegerField(primary_key=True)
    Student_name = models.CharField(max_length=200)
    Student_fathername = models.CharField(max_length=200)
    Departmen = models.CharField(max_length=20)
    Room_id = models.IntegerField(unique=True)
    cell_no = models.IntegerField(unique=True)
    Age = models.IntegerField(null=False)


'''
class Hostel(models.Model):
    Building_num = models.CharField(max_length=20)
    No_of_rooms = models.IntegerField()
    No_of_students = models.IntegerField()
    Annual_expenses = models.IntegerField()
    Location = models.CharField(max_length=40)

class Mess_employee(models.Model):
    Emp_id = models.IntegerField()
    Emp_name = models.CharField(max_length=90)
    Address  = models.CharField(max_length=90)
    Emp_salary = models.IntegerField()
    Cell_no=models.IntegerField(unique=True)
    Hostel_Building_num = models.ForeignKey('Hostel',on_delete = models.CASCADE)
    Mess_Mess_Incharge = models.ForeignKey('Mess',on_delete = models.CASCADE)

class Room(models.Model):
    Room_id = models.IntegerField()
    Capicity = models.IntegerField()
    Furniture_id = models.IntegerField()
    hostel_building_num = models.ForeignKey('Hostel',on_delete = models.CASCADE)
    Student_name = models.CharField(max_length=200)

class Fee(models.Model):
    Fee_month = models.CharField(max_length=20)
    Fee_status = models.CharField(max_length=20)
    Students_Student_id = models.ForeignKey('Students',on_delete = models.CASCADE)

class Visitor(models.Model):
    CNIC = models.IntegerField()
    Students_id = models.ForeignKey('Students',on_delete = models.CASCADE)
    Time_in = models.TimeField()
    Time_out= models.TimeField()
    Date = models.DateField()

class Furniture(models.Model):
    Furniture_id = models.IntegerField()
    Furniture_type = models.CharField(max_length=40)
    Room_Room_id =models.ForeignKey('Room',on_delete = models.CASCADE)

class Mess(models.Model):
    Mess_incharge = models.IntegerField(null=False)
    Monthly_expenses = models.IntegerField()
    Mess_timing = models.TimeField()

'''