from django.shortcuts import render
from django.http import HttpResponseRedirect
from django.contrib.auth import authenticate, login, logout
from .models import Students
from django.contrib.auth.models import User
from django import forms
from  .models import *
from django.contrib.auth.models import User
from django.contrib import auth
from django.views import generic
from django.core.exceptions import ObjectDoesNotExist


class userform(forms.ModelForm):
    username = forms.CharField(widget=forms.TextInput(attrs={'class':'form-control','placeholder':'Enter username'}),required=True,max_length=50)
    email = forms.CharField(widget=forms.EmailInput(attrs={'class': 'form-control', 'placeholder': 'Enter Emailid'}),
                               required=True, max_length=50)
    first_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter first name'}),
                               required=True, max_length=50)
    last_name = forms.CharField(widget=forms.TextInput(attrs={'class': 'form-control', 'placeholder': 'Enter last name'}),
                               required=True, max_length=50)
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'Enter password'}),
                               required=True, max_length=50)
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={'class': 'form-control', 'placeholder': 'confirm password'}),
                               required=True, max_length=50)

    class Meta():
        model=User
        fields = ['username','email','first_name','last_name','password']
# Create your views here.
def index(request):
    return render(request,"hbtuhostelmgmnt/index.html")



def add_hostel(request):
    return render(request, "hbtuhostelmgmnt/header.html")

def add_hostel_form_submission(request):
    try:
        print("form submission")
        Student_id = request.POST["Student_id"]
        Student_name = request.POST["Student_name"]
        Student_fathername = request.POST["Student_fathername"]
        Departmen = request.POST["Departmen"]
        Room_id = request.POST["Room_id"]
        cell_no = request.POST["cell_no"]
        Age = request.POST["Age"]


        Stu = Students(Student_id=Student_id, Student_name=Student_name, Student_fathername=Student_fathername,
                       Departmen=Departmen, Room_id=Room_id, cell_no=cell_no, Age=Age,)
        Stu.save()
        return render(request, "hbtuhostelmgmnt/payment.html")
    except:
        return render(request, "hbtuhostelmgmnt/header.html")
def registration(request):
    if request.method =='POST':
        form1 = userform(request.POST)
        if form1.is_valid():
            username = form1.cleaned_data['username']
            email = form1.cleaned_data['email']
            first_name = form1.cleaned_data['first_name']
            last_name = form1.cleaned_data['last_name']
            password = form1.cleaned_data['password']
            User.objects.create_user(username=username,email=email,first_name=first_name,last_name=last_name,password=password)
            return  HttpResponseRedirect('/login/')
    else:
        form1 = userform()
    return render(request,'hbtuhostelmgmnt/registration.html',{'frm':form1})

def studentsinfo(request):
    all_students = Students.objects.all()
    return render(request,"hbtuhostelmgmnt/studentsinfo.html",{'Students':all_students})

def login(request):
    if request.method=="POST":
        username =request.POST['username']
        password =request.POST['password']
        try:
            user = auth.authenticate(username=username,password=password)
            if user is not None:
                auth.login(request,user)
                return render(request,'hbtuhostelmgmnt/header.html')
            else:
                messages.error(request,'Username and password does not matched')
        except auth.ObjectNotExist:
            print("Invalid user")
    return render(request,'hbtuhostelmgmnt/login.html')

def logout(request):
    auth.logout(request)
    return  HttpResponseRedirect('/')

def payment(request):
    return render(request, "hbtuhostelmgmnt/payment.html")

