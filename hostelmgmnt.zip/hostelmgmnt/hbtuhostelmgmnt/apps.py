from django.apps import AppConfig


class HbtuhostelmgmntConfig(AppConfig):
    name = 'hbtuhostelmgmnt'
