from django.contrib import admin
from django.contrib.auth.models import Group
from .models import Students #,Hostel,Mess_employee,Mess,Furniture,Fee,Visitor,Room
admin.site.site_header = "HBTU Hostel Manager"
admin.site.site_title = "HBTU HMS Admin Portal"
admin.site.index_title = "Welcome to HBTU HMS Portal"
admin.site.register(Students)
'''
admin.site.register(Hostel)
admin.site.register(Mess)
admin.site.register(Mess_employee)
admin.site.register(Furniture)
admin.site.register(Fee)
admin.site.register(Visitor)
admin.site.register(Room)
'''
